import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/postcss';
import {fileURLToPath} from 'node:url';
const path=(p:string)=>fileURLToPath(new URL(p,import.meta.url));
export default defineConfig({root:path('./public-build/'),publicDir:path('./public/'),plugins:[react()],css:{postcss:{plugins:[tailwindcss()]}},build:{outDir:path('./dist-public/'),emptyOutDir:true}});
